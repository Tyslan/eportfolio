﻿Public Class RPGv2

    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged
        If TextBox1.TextLength <> 0 Then
            BtnGenerate.Enabled = True
        Else
            BtnGenerate.Enabled = False
        End If

    End Sub

    Private Sub BtnGenerate_Click(sender As System.Object, e As System.EventArgs) Handles BtnGenerate.Click

        LblText.Text = ""

        Try


            My.Computer.Audio.Play(My.Resources.ButtonHover, AudioPlayMode.Background)


            My.Computer.Audio.Play(My.Resources.Arrive, AudioPlayMode.Background)

            MessageBox.Show("Hello " & TextBox1.Text)

            If TextBox1.Text = "Sion" OrElse TextBox1.Text = "sion" Then

                LblText.Text = "Hello " & TextBox1.Text & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Welcome to the mystic world " & Form1.game.getWorld & vbCrLf
                LblText.Text = LblText.Text & "To return to your own world you need to survive your journey through " & Form1.game.getWorld & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Let's face it Sion, you're too fat to survive dangers of " & Form1.game.getWorld & "."

            ElseIf Form1.game.getWorld = "Texas" Then

                LblText.Text = "Hello " & TextBox1.Text & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Welcome to the mystic world " & Form1.game.getWorld & vbCrLf
                LblText.Text = LblText.Text & "To return to your own world you need to survive your journey through " & Form1.game.getWorld & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Who am I kidding, nobody survives in Texas. Only Joren does."

            ElseIf TextBox1.Text = "Joren" OrElse TextBox1.Text = "joren" Then

                LblText.Text = "Hello " & TextBox1.Text & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Welcome to the mystic world " & Form1.game.getWorld & vbCrLf
                LblText.Text = LblText.Text & "To return to your own world you need to survive your journey through " & Form1.game.getWorld & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Let's skip the journey Joren, we all know you're too legendary to die on this world."

            Else

                LblText.Text = "Hello " & TextBox1.Text & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & Form1.game.makeStory
            End If

            Form1.game.dead = False
            Form1.game.setGame()

        Catch ex As Exception
            MessageBox.Show("An unexpected error has occurred")
            BtnReset.PerformClick()
        End Try

        My.Computer.Audio.Play(My.Resources.Trouble_1, AudioPlayMode.Background)

    End Sub

    Private Sub BtnReset_Click(sender As System.Object, e As System.EventArgs) Handles BtnReset.Click
        BtnGenerate.Enabled = False
        TextBox1.Text = ""
        LblText.Text = ""
        My.Computer.Audio.Play(My.Resources.Trouble_1, AudioPlayMode.Background)
    End Sub

    Private Sub RPGv2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Btnclose_Click(sender As System.Object, e As System.EventArgs) Handles Btnclose.Click
        Me.Close()
    End Sub
End Class
