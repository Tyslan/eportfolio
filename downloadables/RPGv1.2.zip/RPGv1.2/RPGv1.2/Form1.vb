﻿

Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Dim Rpg As New RPGv2
        Rpg.ShowDialog()
        Me.Close()

    End Sub

    Public game As New Game

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play(My.Resources.Trouble_1, AudioPlayMode.Background)
    End Sub
End Class