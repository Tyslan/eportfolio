﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Battle
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Battle))
        Me.BtnAttack1 = New System.Windows.Forms.Button()
        Me.BtnAttack2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LblYourHP = New System.Windows.Forms.Label()
        Me.LblmonsterHP = New System.Windows.Forms.Label()
        Me.BtnAttack3 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.LblEncounter = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.LblMonster = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'BtnAttack1
        '
        Me.BtnAttack1.Location = New System.Drawing.Point(41, 163)
        Me.BtnAttack1.Name = "BtnAttack1"
        Me.BtnAttack1.Size = New System.Drawing.Size(107, 44)
        Me.BtnAttack1.TabIndex = 0
        Me.BtnAttack1.UseVisualStyleBackColor = True
        '
        'BtnAttack2
        '
        Me.BtnAttack2.Location = New System.Drawing.Point(154, 163)
        Me.BtnAttack2.Name = "BtnAttack2"
        Me.BtnAttack2.Size = New System.Drawing.Size(107, 44)
        Me.BtnAttack2.TabIndex = 1
        Me.BtnAttack2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(38, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Your HP:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(38, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Monsters HP:"
        '
        'LblYourHP
        '
        Me.LblYourHP.AutoSize = True
        Me.LblYourHP.Location = New System.Drawing.Point(124, 21)
        Me.LblYourHP.Name = "LblYourHP"
        Me.LblYourHP.Size = New System.Drawing.Size(24, 13)
        Me.LblYourHP.TabIndex = 4
        Me.LblYourHP.Text = "text"
        '
        'LblmonsterHP
        '
        Me.LblmonsterHP.AutoSize = True
        Me.LblmonsterHP.Location = New System.Drawing.Point(124, 48)
        Me.LblmonsterHP.Name = "LblmonsterHP"
        Me.LblmonsterHP.Size = New System.Drawing.Size(24, 13)
        Me.LblmonsterHP.TabIndex = 5
        Me.LblmonsterHP.Text = "text"
        '
        'BtnAttack3
        '
        Me.BtnAttack3.Location = New System.Drawing.Point(267, 163)
        Me.BtnAttack3.Name = "BtnAttack3"
        Me.BtnAttack3.Size = New System.Drawing.Size(107, 44)
        Me.BtnAttack3.TabIndex = 6
        Me.BtnAttack3.UseVisualStyleBackColor = True
        '
        'LblEncounter
        '
        Me.LblEncounter.Location = New System.Drawing.Point(44, 119)
        Me.LblEncounter.Name = "LblEncounter"
        Me.LblEncounter.Size = New System.Drawing.Size(330, 27)
        Me.LblEncounter.TabIndex = 7
        Me.LblEncounter.Text = "Label3"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(267, 21)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(107, 44)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Flee"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'LblMonster
        '
        Me.LblMonster.AutoSize = True
        Me.LblMonster.Location = New System.Drawing.Point(44, 89)
        Me.LblMonster.Name = "LblMonster"
        Me.LblMonster.Size = New System.Drawing.Size(39, 13)
        Me.LblMonster.TabIndex = 9
        Me.LblMonster.Text = "Label3"
        '
        'Battle
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(413, 239)
        Me.Controls.Add(Me.LblMonster)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.LblEncounter)
        Me.Controls.Add(Me.BtnAttack3)
        Me.Controls.Add(Me.LblmonsterHP)
        Me.Controls.Add(Me.LblYourHP)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnAttack2)
        Me.Controls.Add(Me.BtnAttack1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Battle"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Battle"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnAttack1 As System.Windows.Forms.Button
    Friend WithEvents BtnAttack2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LblYourHP As System.Windows.Forms.Label
    Friend WithEvents LblmonsterHP As System.Windows.Forms.Label
    Friend WithEvents BtnAttack3 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents LblEncounter As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents LblMonster As System.Windows.Forms.Label
End Class
