﻿Public Class Game

    Private World As String
    Private Monster As String
    Private Attack As String
    Private Adjective As String

    Private MonsterList As New List(Of String)
    Private WorldList As New List(Of String)
    Private AttackList As New List(Of String)
    Private AdjectiveList As New List(Of String)

    Public dead As Boolean = False

    Public Sub New()
        fillWorldList()
        fillMonsterList()
        fillAttackList()
        fillAdjectiveList()

        World = pickWorld()
        Monster = pickMonster()
        Adjective = pickAdjective()
        Attack = pickAttack()

    End Sub

    Public Function makeStory() As String
        Dim story As String


        story = "Welcome to the mystic world " & World & vbCrLf
        story = story & "To return to your own world you need to survive your journey through " & World & vbCrLf & vbCrLf
        Dim teller As Integer = 0
        Dim dead As Boolean = False
        Dim form As New Battle

        MessageBox.Show("Welcome to the mystic world " & World & vbCrLf & "To return to your own world you need to survive your journey through " & World)


        While teller < 6 AndAlso Me.dead <> True

            story = story & "You encounter the " & Adjective & " " & Monster & "." & vbCrLf
            story = story & "The " & Adjective & " " & Monster & " tries to " & Attack & " you." & vbCrLf

            Dim previousattack As String = Attack

            Attack = pickAttack()

            form.BtnAttack1.Text = "fast " & Attack
            form.BtnAttack2.Text = Attack
            form.BtnAttack3.Text = "brutal " & Attack
            form.LblEncounter.Text = "You encounter the " & Adjective & " " & Monster
            form.ShowDialog()

            Me.dead = Form1.game.dead

            If Me.dead <> True Then
                story = story & "You " & Attack & " the " & Monster & "." & vbCrLf
                story = story & "The " & Adjective & " " & Monster & " dies." & vbCrLf
                story = story & "You continue your journey." & vbCrLf & vbCrLf

                My.Computer.Audio.Play(My.Resources.Playerwinmonster, AudioPlayMode.WaitToComplete)

                MessageBox.Show("The " & Adjective & " " & Monster & " dies." & vbCrLf & "You continue your journey.")

                Monster = pickMonster()
                Attack = pickAttack()
                Adjective = pickAdjective()

                teller += 1

            Else

                My.Computer.Audio.Play(My.Resources.Monsterwin, AudioPlayMode.WaitToComplete)

                story = story & "The " & Adjective & " " & Monster & " " & previousattack & "s you." & vbCrLf
                story = story & "You die." & vbCrLf & vbCrLf

                MessageBox.Show("The " & Adjective & " " & Monster & " " & previousattack & "s you." & vbCrLf & "You died")
            End If
        End While

        Dim boss As New BossBattle

        If teller = 6 Then
            story = story & "You see the portal to reach your homeworld." & vbCrLf
            story = story & "As you reach the portal wild " & Adjective & " " & Monster & " appears." & vbCrLf

            MessageBox.Show("You see the portal to reach your homeworld" & vbCrLf & "As you reach the portal wild " & Adjective & " " & Monster & " appears.")

            My.Computer.Audio.Play(My.Resources.Boss, AudioPlayMode.WaitToComplete)

            Dim previousattack As String = Attack

            Attack = pickAttack()

            boss.BtnAttack1.Text = "fast " & Attack
            boss.BtnAttack2.Text = Attack
            boss.BtnAttack3.Text = "brutal " & Attack
            boss.LblEncounter.Text = "You encounter the " & Adjective & " " & Monster
            boss.ShowDialog()

            If Me.dead <> True Then
                story = story & "The " & Adjective & " " & Monster & " tries to " & Attack & " you." & vbCrLf
                story = story & "You legendary " & pickAttack() & " the " & Monster & "." & vbCrLf
                story = story & "The " & Adjective & " " & Monster & " screams in terror and dies." & vbCrLf
                My.Computer.Audio.Play(My.Resources.Playerwin, AudioPlayMode.WaitToComplete)
                story = story & "You safely return to your homeworld, leaving a trail of dead creatures behind and you remember this as a bad dream."

                MessageBox.Show("You legendary " & pickAttack() & " the " & Monster & "." & vbCrLf & "The " & Adjective & " " & Monster & " screams in terror and dies.")
                MessageBox.Show("You safely return to your homeworld, leaving a trail of dead creatures behind and you remember this as a bad dream.")
            Else
                My.Computer.Audio.Play(My.Resources.Bosswin, AudioPlayMode.WaitToComplete)
                story = story & "The " & Adjective & " " & Monster & " " & previousattack & "s you." & vbCrLf
                story = story & "You scream in terror and die while remembering how close you where to returning home."

                MessageBox.Show("The " & Adjective & " " & Monster & " " & previousattack & "s you." & vbCrLf & "You scream in terror and die while remembering how close you where to returning home.")

            End If

        End If

        Return story
    End Function

    Public Sub setGame()
        Adjective = pickAdjective()
        Attack = pickAttack()
        Monster = pickMonster()
        World = pickWorld()
    End Sub

    Public Function getWorld() As String
        Return Me.World
    End Function

    Public Function getMonster() As String
        Return Me.Monster
    End Function

    Public Function getAdjective() As String
        Return Me.Adjective
    End Function

    Private Sub fillMonsterList()
        MonsterList.Add("wolf")
        MonsterList.Add("zombie")
        MonsterList.Add("ogre")
        MonsterList.Add("bat")
        MonsterList.Add("Russian prime minister")
        MonsterList.Add("orc")
        MonsterList.Add("goblin")
        MonsterList.Add("Magikarp")
        MonsterList.Add("Godzilla")
        MonsterList.Add("hippie")
        MonsterList.Add("rat")
        MonsterList.Add("Spock")
        MonsterList.Add("Jack Sparrow")
        MonsterList.Add("demon")
        MonsterList.Add("dwarf")
        MonsterList.Add("Nameless One")
        MonsterList.Add("Chuck Norris")
        MonsterList.Add("rabbit")
    End Sub

    Private Sub fillWorldList()
        WorldList.Add("Kelewan")
        WorldList.Add("Midkermia")
        WorldList.Add("Novindus")
        WorldList.Add("Diskworld")
        WorldList.Add("Agrendar")
        WorldList.Add("Terra")
        WorldList.Add("Crossway")
        WorldList.Add("Texas")
        WorldList.Add("Kanto")
    End Sub

    Private Sub fillAttackList()
        AttackList.Add("bite")
        AttackList.Add("charm")
        AttackList.Add("hug")
        AttackList.Add("impale")
        AttackList.Add("burn")
        AttackList.Add("electocute")
        AttackList.Add("shoot")
        AttackList.Add("stab")
        AttackList.Add("slap")
        AttackList.Add("love")
        AttackList.Add("mock")
        AttackList.Add("bludgeon")
        AttackList.Add("tickle")
        AttackList.Add("crush")
        AttackList.Add("poison")
    End Sub

    Private Sub fillAdjectiveList()
        AdjectiveList.Add("green")
        AdjectiveList.Add("red")
        AdjectiveList.Add("massive")
        AdjectiveList.Add("rather attractive")
        AdjectiveList.Add("goldloving")
        AdjectiveList.Add("demonic")
        AdjectiveList.Add("corrupt")
        AdjectiveList.Add("lighting fast")
        AdjectiveList.Add("high")
        AdjectiveList.Add("charming")
        AdjectiveList.Add("crazy")
        AdjectiveList.Add("tall")
        AdjectiveList.Add("furry")
        AdjectiveList.Add("chinese")
        AdjectiveList.Add("fat")
        AdjectiveList.Add("humorless")
        AdjectiveList.Add("legendary")
        AdjectiveList.Add("lazy")
        AdjectiveList.Add("hyper-active")
        AdjectiveList.Add("sleeply")
        AdjectiveList.Add("sneezy")
        AdjectiveList.Add("squishy")
    End Sub

    Public Function pickWorld() As String
        Dim world As String
        Dim n As Integer = GetRandom(0, WorldList.Count - 1)
        world = WorldList.Item(n)
        Return world
    End Function

    Public Function pickMonster() As String
        Dim monster As String
        Dim n As Integer = GetRandom(0, MonsterList.Count - 1)
        monster = MonsterList.Item(n)
        Return monster
    End Function

    Public Function pickAdjective() As String
        Dim adjective As String
        Dim n As Integer = GetRandom(0, AdjectiveList.Count - 1)
        adjective = AdjectiveList.Item(n)
        Return adjective
    End Function

    Public Function pickAttack() As String
        Dim attack As String
        Dim n As Integer = GetRandom(0, AttackList.Count - 1)
        attack = AttackList.Item(n)
        Return attack
    End Function

    Private Function isAlive() As Boolean
        If (GetRandom(0, 4) Mod 4) = 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
        ' by making Generator static, we preserve the same instance '
        ' (i.e., do not create new instances with the same seed over and over) '
        ' between calls '
        Static Generator As System.Random = New System.Random()
        Return Generator.Next(Min, Max)
    End Function

    Private Sub wait(ByVal interval As Integer)
        Dim sw As New Stopwatch
        sw.Start()
        Do While sw.ElapsedMilliseconds < interval
            ' Allows UI to remain responsive
            Application.DoEvents()
        Loop
        sw.Stop()
    End Sub
End Class
