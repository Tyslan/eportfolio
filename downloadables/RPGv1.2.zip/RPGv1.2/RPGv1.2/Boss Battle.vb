﻿Public Class BossBattle

    Public special As Integer

    Private Sub Battle_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        LblYourHP.Text = "150"
        LblmonsterHP.Text = "200"
        LblMonster.Text = ""
    End Sub

    Private Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
        ' by making Generator static, we preserve the same instance '
        ' (i.e., do not create new instances with the same seed over and over) '
        ' between calls '
        Static Generator As System.Random = New System.Random()
        Return Generator.Next(Min, Max)
    End Function

    Private Function FalterAttack() As Boolean
        If (GetRandom(0, 11) Mod 10) = 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Function FalterSpecial() As Boolean
        If (GetRandom(0, 5) Mod 4) = 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function FalterMonster() As Boolean
        If (GetRandom(0, 11) Mod 10) = 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function FalterMonsterSpecial() As Boolean
        If (GetRandom(0, 5) Mod 4) = 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function monsterAttack() As Integer
        Dim nummer As Integer = GetRandom(0, 200)
        If (nummer Mod 4) = 1 Then
            Return 35
        ElseIf (nummer Mod 4) = 2 Then
            If FalterMonster() <> True Then
                Return 40
            Else
                Return 0
            End If
        ElseIf (nummer Mod 4) = 3 Then
            If FalterMonsterSpecial() <> True Then
                Return 55
            Else
                Return 0
            End If
        Else
            Return 0
        End If
    End Function

    Private Sub BtnAttack1_Click(sender As System.Object, e As System.EventArgs) Handles BtnAttack1.Click
        Dim myhealth As Integer = Convert.ToInt32(LblYourHP.Text)
        Dim monsterhealth As Integer = Convert.ToInt32(LblmonsterHP.Text)

        LblMonster.Text = "You encountered the " & Form1.game.getAdjective & " " & Form1.game.getMonster

        Dim aanval As Integer = monsterAttack()

        myhealth -= aanval

        monsterhealth -= 20

        LblEncounter.Text = "You succeeded in your attack"

        If myhealth <= 0 Then
            Form1.game.dead = True
            Me.Close()
        ElseIf monsterhealth <= 0 Then
            Form1.game.dead = False
            Me.Close()
        Else
            LblYourHP.Text = myhealth
            LblmonsterHP.Text = monsterhealth
        End If
    End Sub


    Private Sub BtnAttack2_Click(sender As System.Object, e As System.EventArgs) Handles BtnAttack2.Click
        Dim myhealth As Integer = Convert.ToInt32(LblYourHP.Text)
        Dim monsterhealth As Integer = Convert.ToInt32(LblmonsterHP.Text)

        LblMonster.Text = "You encountered the " & Form1.game.getAdjective & " " & Form1.game.getMonster

        myhealth -= monsterAttack()

        If FalterAttack() = True Then
            LblEncounter.Text = "Your opponent parries your attack"
        Else
            monsterhealth -= 30
            LblEncounter.Text = "You succeeded in your attack"
        End If

        If myhealth <= 0 Then
            Form1.game.dead = True
            Me.Close()
        ElseIf monsterhealth <= 0 Then
            Form1.game.dead = False
            Me.Close()
        Else
            LblYourHP.Text = myhealth
            LblmonsterHP.Text = monsterhealth
        End If
    End Sub

    Private Sub BtnAttack3_Click(sender As System.Object, e As System.EventArgs) Handles BtnAttack3.Click
        Dim myhealth As Integer = Convert.ToInt32(LblYourHP.Text)
        Dim monsterhealth As Integer = Convert.ToInt32(LblmonsterHP.Text)

        LblMonster.Text = "You encountered the " & Form1.game.getAdjective & " " & Form1.game.getMonster

        myhealth -= monsterAttack()

        If FalterSpecial() = True Then
            LblEncounter.Text = "Your opponent parries your attack"
        Else
            monsterhealth -= 60
            LblEncounter.Text = "You succeeded in your attack"
        End If

        If myhealth <= 0 Then
            Form1.game.dead = True
            Me.Close()
        ElseIf monsterhealth <= 0 Then
            Form1.game.dead = False
            Me.Close()
        Else
            LblYourHP.Text = myhealth
            LblmonsterHP.Text = monsterhealth
        End If
    End Sub


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        MessageBox.Show("The monster comes after you")
        Form1.game.dead = True
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim myhealth As Integer = Convert.ToInt32(LblYourHP.Text)
        Dim monsterhealth As Integer = Convert.ToInt32(LblmonsterHP.Text)

        LblMonster.Text = "You encountered the " & Form1.game.getAdjective & " " & Form1.game.getMonster

        myhealth -= monsterAttack()

        myhealth += 30

        If myhealth <= 0 Then
            Form1.game.dead = True
            Me.Close()
        ElseIf monsterhealth <= 0 Then
            Form1.game.dead = False
            Me.Close()
        Else
            LblYourHP.Text = myhealth
            LblmonsterHP.Text = monsterhealth
        End If

    End Sub
End Class