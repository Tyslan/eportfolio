﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RPG
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnGenerate = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.LblNaam = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.LblText = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'BtnGenerate
        '
        Me.BtnGenerate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnGenerate.Enabled = False
        Me.BtnGenerate.Location = New System.Drawing.Point(12, 551)
        Me.BtnGenerate.Name = "BtnGenerate"
        Me.BtnGenerate.Size = New System.Drawing.Size(138, 43)
        Me.BtnGenerate.TabIndex = 0
        Me.BtnGenerate.Text = "&Generate story"
        Me.BtnGenerate.UseVisualStyleBackColor = True
        '
        'BtnReset
        '
        Me.BtnReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnReset.Location = New System.Drawing.Point(12, 614)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(138, 43)
        Me.BtnReset.TabIndex = 1
        Me.BtnReset.Text = "&Reset"
        Me.BtnReset.UseVisualStyleBackColor = True
        '
        'LblNaam
        '
        Me.LblNaam.AutoSize = True
        Me.LblNaam.Location = New System.Drawing.Point(12, 14)
        Me.LblNaam.Name = "LblNaam"
        Me.LblNaam.Size = New System.Drawing.Size(38, 13)
        Me.LblNaam.TabIndex = 2
        Me.LblNaam.Text = "Name:"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 46)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(134, 20)
        Me.TextBox1.TabIndex = 1
        '
        'LblText
        '
        Me.LblText.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblText.BackColor = System.Drawing.SystemColors.ControlLight
        Me.LblText.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblText.Location = New System.Drawing.Point(203, 14)
        Me.LblText.Name = "LblText"
        Me.LblText.Size = New System.Drawing.Size(400, 642)
        Me.LblText.TabIndex = 4
        '
        'RPG
        '
        Me.AcceptButton = Me.BtnGenerate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(622, 669)
        Me.Controls.Add(Me.LblText)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LblNaam)
        Me.Controls.Add(Me.BtnReset)
        Me.Controls.Add(Me.BtnGenerate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "RPG"
        Me.Text = "RPG"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnGenerate As System.Windows.Forms.Button
    Friend WithEvents BtnReset As System.Windows.Forms.Button
    Friend WithEvents LblNaam As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents LblText As System.Windows.Forms.Label

End Class
