﻿Public Class RPG

    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged
        If TextBox1.TextLength <> 0 Then
            BtnGenerate.Enabled = True
        Else
            BtnGenerate.Enabled = False
        End If

    End Sub

    Private Sub BtnGenerate_Click(sender As System.Object, e As System.EventArgs) Handles BtnGenerate.Click
        Try
            LblText.Text = "Hello " & TextBox1.Text & vbCrLf & vbCrLf
            Dim game As New Game
            If TextBox1.Text = "Sion" OrElse TextBox1.Text = "sion" Then
                LblText.Text = LblText.Text & "Welcome to the mystic world " & game.getWorld & vbCrLf
                LblText.Text = LblText.Text & "To return to your own world you need to survive your journey through " & game.getWorld & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Let's face it Sion, you're too fat to survive dangers of " & game.getWorld & "."

            ElseIf game.getWorld = "Texas" Then
                LblText.Text = LblText.Text & "Welcome to the mystic world " & game.getWorld & vbCrLf
                LblText.Text = LblText.Text & "To return to your own world you need to survive your journey through " & game.getWorld & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Who am I kidding, nobody survives in Texas. Or maybe Joren does."

            ElseIf TextBox1.Text = "Joren" OrElse TextBox1.Text = "joren" Then
                LblText.Text = LblText.Text & "Welcome to the mystic world " & game.getWorld & vbCrLf
                LblText.Text = LblText.Text & "To return to your own world you need to survive your journey through " & game.getWorld & vbCrLf & vbCrLf
                LblText.Text = LblText.Text & "Let's skip the journey Joren, we all know you're too legendary to die on this world."

            Else
                LblText.Text = LblText.Text & game.makeStory
            End If

        Catch ex As Exception
            MessageBox.Show("An unexpected error has occurred")
            BtnReset.PerformClick()
        End Try

    End Sub

    Private Sub BtnReset_Click(sender As System.Object, e As System.EventArgs) Handles BtnReset.Click
        BtnGenerate.Enabled = False
        TextBox1.Text = ""
        LblText.Text = ""
    End Sub
End Class
