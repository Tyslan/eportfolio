﻿Imports System.Drawing.Graphics

Public Class Poolvergelijking

    Private vgl As Poolvgl

    Private Sub BtnEind_Click(sender As System.Object, e As System.EventArgs) Handles BtnEind.Click
        Me.Close()
    End Sub

    Private Sub Rdb_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles Rdb6.CheckedChanged, Rdb16.CheckedChanged, RdbE.CheckedChanged, RdbPi.CheckedChanged
        Dim rbttn As RadioButton = CType(sender, RadioButton)
        If rbttn.Text = "6" Then
            vgl.setN() = 6
            PcbDoek.Invalidate()
        ElseIf rbttn.Text = "1/6" Then
            vgl.setN() = 1 / 6
            PcbDoek.Invalidate()
        ElseIf rbttn.Text = "Pi" Then
            vgl.setN() = Math.PI
            PcbDoek.Invalidate()
        ElseIf rbttn.Text = "e" Then
            vgl.setN() = Math.E
            PcbDoek.Invalidate()
        End If
    End Sub

    Private Sub Poolvergelijking_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        vgl = New Poolvgl(6, PcbDoek.ClientSize.Width / 2)
    End Sub

    Private Sub PcbDoek_Paint1(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles PcbDoek.Paint
        Dim g As Graphics = e.Graphics

        g.TranslateTransform(PcbDoek.ClientSize.Width / 2, PcbDoek.ClientSize.Height / 2)
        g.ScaleTransform(1, -1)

        Using p As Pen = New Pen(Color.Black, 1)

            'g.DrawLine(p, 0, 0, 0, PcbDoek.ClientSize.Height)
            'g.DrawLine(p, PcbDoek.ClientSize.Width, 0, 0, 0)

            For Teller As Integer = 1 To (vgl.getPuntList.count - 2)
                g.DrawLine(p, vgl.getPunt(Teller - 1), vgl.getPunt(Teller))
            Next
        End Using
    End Sub

    Private Sub Poolvergelijking_Resize(sender As Object, e As System.EventArgs) Handles Me.Resize
        PcbDoek.Invalidate()
    End Sub
End Class
