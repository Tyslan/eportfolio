﻿Imports System.Math

Public Class Poolvgl
    Private theta As Double = 0
    Private r As Double
    Private n As Double
    Private a As Double

    Private Points As List(Of Point) = New List(Of Point)

    Public Sub New(ByVal n As Double, ByVal a As Double)
        Me.n = n
        Me.a = a

        berekenPunten()

    End Sub

    Public ReadOnly Property getX(ByVal i As Integer) As Double
        Get
            Return Points(i).X
        End Get
    End Property

    Public ReadOnly Property getY(ByVal i As Integer) As Double
        Get
            Return Points(i).Y
        End Get
    End Property

    Public ReadOnly Property getPunt(ByVal i As Integer) As Point
        Get
            Return Points(i)
        End Get
    End Property

    Public ReadOnly Property getPuntlist() As List(Of Point)
        Get
            Return Points
        End Get
    End Property

    Public WriteOnly Property setN()
        Set(value)
            n = value
            berekenPunten()
        End Set
    End Property

    Private Sub berekenPunten()
        Dim r As Double
        Dim y As Double
        Dim x As Double
        Dim i As Double = -a / 2

        Points.Clear()

        While i < a / 2

            r = a * Sin(n * i)

            x = r * Cos(i)
            y = r * Sin(i)

            'Debug.WriteLine(x & "," & y)
            Dim P As Point = New Point(x, y)

            Points.Add(P)
            i += 0.01
        End While
    End Sub
End Class
