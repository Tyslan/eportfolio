﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Poolvergelijking
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PcbDoek = New System.Windows.Forms.PictureBox()
        Me.BtnEind = New System.Windows.Forms.Button()
        Me.Rdb6 = New System.Windows.Forms.RadioButton()
        Me.Rdb16 = New System.Windows.Forms.RadioButton()
        Me.RdbPi = New System.Windows.Forms.RadioButton()
        Me.RdbE = New System.Windows.Forms.RadioButton()
        CType(Me.PcbDoek, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PcbDoek
        '
        Me.PcbDoek.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PcbDoek.BackColor = System.Drawing.Color.White
        Me.PcbDoek.Location = New System.Drawing.Point(21, 12)
        Me.PcbDoek.Name = "PcbDoek"
        Me.PcbDoek.Size = New System.Drawing.Size(450, 450)
        Me.PcbDoek.TabIndex = 0
        Me.PcbDoek.TabStop = False
        '
        'BtnEind
        '
        Me.BtnEind.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.BtnEind.Location = New System.Drawing.Point(21, 484)
        Me.BtnEind.Name = "BtnEind"
        Me.BtnEind.Size = New System.Drawing.Size(75, 23)
        Me.BtnEind.TabIndex = 1
        Me.BtnEind.Text = "&Eind"
        Me.BtnEind.UseVisualStyleBackColor = True
        '
        'Rdb6
        '
        Me.Rdb6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Rdb6.AutoSize = True
        Me.Rdb6.Checked = True
        Me.Rdb6.Location = New System.Drawing.Point(120, 484)
        Me.Rdb6.Name = "Rdb6"
        Me.Rdb6.Size = New System.Drawing.Size(31, 17)
        Me.Rdb6.TabIndex = 2
        Me.Rdb6.TabStop = True
        Me.Rdb6.Text = "6"
        Me.Rdb6.UseVisualStyleBackColor = True
        '
        'Rdb16
        '
        Me.Rdb16.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Rdb16.AutoSize = True
        Me.Rdb16.Location = New System.Drawing.Point(120, 508)
        Me.Rdb16.Name = "Rdb16"
        Me.Rdb16.Size = New System.Drawing.Size(42, 17)
        Me.Rdb16.TabIndex = 3
        Me.Rdb16.TabStop = True
        Me.Rdb16.Text = "1/6"
        Me.Rdb16.UseVisualStyleBackColor = True
        '
        'RdbPi
        '
        Me.RdbPi.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RdbPi.AutoSize = True
        Me.RdbPi.Location = New System.Drawing.Point(180, 484)
        Me.RdbPi.Name = "RdbPi"
        Me.RdbPi.Size = New System.Drawing.Size(34, 17)
        Me.RdbPi.TabIndex = 4
        Me.RdbPi.TabStop = True
        Me.RdbPi.Text = "Pi"
        Me.RdbPi.UseVisualStyleBackColor = True
        '
        'RdbE
        '
        Me.RdbE.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RdbE.AutoSize = True
        Me.RdbE.Location = New System.Drawing.Point(180, 508)
        Me.RdbE.Name = "RdbE"
        Me.RdbE.Size = New System.Drawing.Size(31, 17)
        Me.RdbE.TabIndex = 5
        Me.RdbE.TabStop = True
        Me.RdbE.Text = "e"
        Me.RdbE.UseVisualStyleBackColor = True
        '
        'Poolvergelijking
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(495, 559)
        Me.Controls.Add(Me.RdbE)
        Me.Controls.Add(Me.RdbPi)
        Me.Controls.Add(Me.Rdb16)
        Me.Controls.Add(Me.Rdb6)
        Me.Controls.Add(Me.BtnEind)
        Me.Controls.Add(Me.PcbDoek)
        Me.Name = "Poolvergelijking"
        Me.Text = "Form1"
        CType(Me.PcbDoek, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PcbDoek As System.Windows.Forms.PictureBox
    Friend WithEvents BtnEind As System.Windows.Forms.Button
    Friend WithEvents Rdb6 As System.Windows.Forms.RadioButton
    Friend WithEvents Rdb16 As System.Windows.Forms.RadioButton
    Friend WithEvents RdbPi As System.Windows.Forms.RadioButton
    Friend WithEvents RdbE As System.Windows.Forms.RadioButton

End Class
