﻿Imports System.Threading
Public Delegate Sub bepaalOplossing()

Public Class _8QueensModel
    Private schaakbord(7, 7) As Boolean
    Private aantalKoninginnen As Integer
    Private bewegingen As New List(Of Point)
    Private generator As OplossingsGenerator
    Private voorbeeldoplossing As New Stack(Of Point)
    Public Sub New()
        initGame()
    End Sub
    Private Sub bepaalOplossing()
        generator = New OplossingsGenerator(New _8QueensModel)
        voorbeeldoplossing = generator.Oplossing
    End Sub
    Public Sub initGame()
        For i As Integer = 0 To 7
            For j As Integer = 0 To 7
                schaakbord(i, j) = True
            Next
        Next
        aantalKoninginnen = 0
        bewegingen.Clear()
    End Sub
    Public Sub plaatsKoningin(ByVal x As Integer, ByVal y As Integer)
        bewegingen.Add(New Point(x, y))
        aantalKoninginnen = aantalKoninginnen + 1
        For i As Integer = 0 To 7
            schaakbord(x, i) = False
            schaakbord(i, y) = False
        Next
        'diagonalen disablen
        Dim hulp_x As Integer = x - 1
        Dim hulp_y As Integer = y - 1
        While hulp_x >= 0 AndAlso hulp_y >= 0
            schaakbord(hulp_x, hulp_y) = False
            hulp_x = hulp_x - 1
            hulp_y = hulp_y - 1
        End While
        hulp_x = x + 1
        hulp_y = y + 1
        While hulp_x < 8 AndAlso hulp_y < 8
            schaakbord(hulp_x, hulp_y) = False
            hulp_x = hulp_x + 1
            hulp_y = hulp_y + 1
        End While
        hulp_x = x + 1
        hulp_y = y - 1
        While hulp_x < 8 AndAlso hulp_y >= 0
            schaakbord(hulp_x, hulp_y) = False
            hulp_x = hulp_x + 1
            hulp_y = hulp_y - 1
        End While
        hulp_x = x - 1
        hulp_y = y + 1
        While hulp_x >= 0 AndAlso hulp_y < 8
            schaakbord(hulp_x, hulp_y) = False
            hulp_x = hulp_x - 1
            hulp_y = hulp_y + 1
        End While
    End Sub
    Public Sub verwijderLaatsteKoningin()
        bewegingen.RemoveAt(bewegingen.Count - 1)
        Dim hulp As New List(Of Point)
        hulp = bewegingen.ToList
        initGame()
        For Each p As Point In hulp
            plaatsKoningin(p.X, p.Y)
        Next
    End Sub
    Public Function kanDameGeplaatstWorden(ByVal x As Integer, ByVal y As Integer)
        Return schaakbord(x, y)
    End Function
    Public ReadOnly Property Vakje_Bedreigd(ByVal x As Integer, ByVal y As Integer) As Boolean
        Get
            Return Not schaakbord(x, y)
        End Get
    End Property
    Public Function isBordCompleet() As Boolean
        For i As Integer = 0 To 7
            For j As Integer = 0 To 7
                If schaakbord(i, j) = True Then
                    Return False
                End If
            Next
        Next
        Return True
    End Function
    Public ReadOnly Property GeplaatsteKoninginnen As Integer
        Get
            Return aantalKoninginnen
        End Get
    End Property
    Public ReadOnly Property Vakje_koningin(ByVal x As Integer, ByVal y As Integer) As Boolean
        Get
            Return bewegingen.Contains(New Point(x, y))
        End Get
    End Property
    Public ReadOnly Property Oplossing As Stack(Of Point)

        Get
            bepaalOplossing()
            Return voorbeeldoplossing
        End Get
    End Property

End Class
