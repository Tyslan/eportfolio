﻿Public Class _8QueensForm
    Private schaakbord(,) As MyLabel
    Private WithEvents tlp As New MyTableLayoutPanel
    Private flp As New FlowLayoutPanel
    Private WithEvents bttnReset As Button
    Private WithEvents bttnEinde As Button
    Private WithEvents bttnUndo As Button
    Private WithEvents bttnOplossing As Button
    Private model As New _8QueensModel
    Private handlercount As Integer = 0

    Public Sub New()
        InitializeComponent()
        initTLPanel()
        initSchaakbord()
        initFLPanel()
        ClientSize = New Size(40 + tlp.Size.Width + 40, 40 + tlp.Size.Height + 40 + flp.Height + 40)
        MinimumSize = Size
        Me.DoubleBuffered = True
        AddHandler Me.Resize, AddressOf _8QueensForm_Resize
    End Sub

    Private Sub initTLPanel()
        tlp.ColumnCount = 8
        tlp.RowCount = 8
        tlp.Location = New Point(40, 40)
        tlp.AutoSize = True
        tlp.AutoSizeMode = Windows.Forms.AutoSizeMode.GrowAndShrink
        tlp.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset
        For i As Integer = 0 To 7
            tlp.RowStyles.Add(New RowStyle(SizeType.Absolute, 50))
            tlp.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 50))
        Next
        Controls.Add(tlp)
    End Sub
    Private Sub initFLPanel()
        bttnReset = New Button
        bttnReset.Text = "Reset"
        bttnEinde = New Button
        bttnEinde.Text = "Einde"
        bttnReset.AutoSize = True
        bttnReset.Enabled = False
        bttnUndo = New Button
        bttnUndo.Text = "Undo"
        bttnUndo.Enabled = False
        bttnOplossing = New Button
        bttnOplossing.AutoSize = True
        bttnOplossing.Text = "Oplossing"
        bttnUndo.AutoSize = True
        flp.Controls.Add(bttnEinde)
        flp.Controls.Add(bttnUndo)
        flp.Controls.Add(bttnReset)
        flp.Controls.Add(bttnOplossing)
        flp.Margin = New Padding(0, 0, 0, 0)
        bttnEinde.Margin = New Padding(0, 0, 10, 0)
        bttnUndo.Margin = New Padding(10, 0, 10, 0)
        bttnReset.Margin = New Padding(10, 0, 10, 0)
        bttnOplossing.Margin = New Padding(10, 0, 10, 0)
        flp.Size = New Size(tlp.Width, bttnReset.Size.Height)
        flp.Location = New Point(40, 40 + tlp.Height + 40)
        Controls.Add(flp)
    End Sub
    Private Sub initSchaakbord()
        schaakbord = New MyLabel(7, 7) {}
        For i As Integer = 0 To 7
            For j As Integer = 0 To 7
                Dim hulplabel As New MyLabel(j, i)
                hulplabel.Dock = DockStyle.Fill
                AddHandler hulplabel.Click, AddressOf Label_Click
                hulplabel.TextAlign = ContentAlignment.MiddleCenter
                If (i + j) Mod 2 = 0 Then
                    hulplabel.BackColor = Color.Khaki
                Else
                    hulplabel.BackColor = Color.Crimson
                End If
                schaakbord(j, i) = hulplabel
                tlp.Controls.Add(hulplabel, j, i)
            Next
        Next
        handlercount = handlercount + 1
    End Sub

    Private Sub _8QueensForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs)
        If ClientSize.Width <> 0 AndAlso ClientSize.Height <> 0 Then
            tlp.SuspendLayout()
            Dim dimensie As Single = Math.Min(Me.ClientSize.Width - 40 - 40, Me.ClientSize.Height - 40 - flp.Height - 40 - 40) / 8
            For i As Integer = 0 To 7
                tlp.RowStyles(i).Height = dimensie
                tlp.ColumnStyles(i).Width = dimensie
            Next
            tlp.ResumeLayout()
            Dim witruimte_horizontaal As Integer = (ClientSize.Width - tlp.Width) \ 2
            Dim witruimte_verticaal As Integer = (ClientSize.Height - tlp.Height - 40 - flp.Height) \ 2
            tlp.Location = New Point(witruimte_horizontaal, witruimte_verticaal)
            flp.Location = New Point(witruimte_horizontaal, witruimte_verticaal + tlp.Height + 40)
        End If
    End Sub

    Private Sub bttnStop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bttnEinde.Click
        Close()
    End Sub

    Private Sub Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim hulplabel As MyLabel = CType(sender, MyLabel)
        If model.kanDameGeplaatstWorden(hulplabel.Y, hulplabel.X) Then
            model.plaatsKoningin(hulplabel.Y, hulplabel.X)
            For i As Integer = 0 To 7
                For j As Integer = 0 To 7
                    If model.Vakje_koningin(i, j) Then
                        schaakbord(j, i).Image = My.Resources.queen
                    ElseIf model.Vakje_Bedreigd(i, j) Then

                        schaakbord(j, i).Text = "X"
                    End If
                Next
            Next
        End If
        bttnUndo.Enabled = True
        bttnReset.Enabled = True
        If model.isBordCompleet AndAlso model.GeplaatsteKoninginnen <> 8 Then
            MessageBox.Show("Er werden geen 8 koninginnen op het bord geplaatst!", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information)
            For Each it As MyLabel In schaakbord
                RemoveHandler it.Click, AddressOf Label_Click
            Next
            handlercount = handlercount - 1
            bttnUndo.Enabled = False
        ElseIf model.GeplaatsteKoninginnen = 8 Then
            For i As Integer = 0 To 7
                For j As Integer = 0 To 7
                    schaakbord(j, i).Text = ""
                    If model.Vakje_koningin(i, j) Then
                        schaakbord(j, i).Image = My.Resources.queen
                    End If
                Next
                bttnUndo.Enabled = False
            Next
            MessageBox.Show("Proficiat, je hebt alle koninginnen kunnen plaatsen!", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information)
            For Each it As MyLabel In schaakbord
                RemoveHandler it.Click, AddressOf Label_Click
            Next
            handlercount = handlercount - 1
        End If
    End Sub

    Private Sub bttnReset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bttnReset.Click
        model.initGame()
        For Each it As MyLabel In schaakbord
            it.Text = ""
            it.Image = Nothing
        Next
        bttnUndo.Enabled = False
        If handlercount = 0 Then
            For Each it As MyLabel In schaakbord
                AddHandler it.Click, AddressOf Label_Click
            Next
            handlercount = handlercount + 1
        End If
        bttnReset.Enabled = False
    End Sub

    Private Sub bttnUndo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bttnUndo.Click
        model.verwijderLaatsteKoningin()
        For i As Integer = 0 To 7
            For j As Integer = 0 To 7
                If model.Vakje_koningin(i, j) Then
                    schaakbord(j, i).Image = My.Resources.queen
                ElseIf model.Vakje_Bedreigd(i, j) Then
                    schaakbord(j, i).Text = "X"
                Else
                    schaakbord(j, i).Text = ""
                    schaakbord(j, i).Image = Nothing
                End If
            Next
        Next
        If model.GeplaatsteKoninginnen = 0 Then
            bttnUndo.Enabled = False
            bttnReset.Enabled = False
        End If
    End Sub

    Private Sub bttnOplossing_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bttnOplossing.Click

        For Each it As MyLabel In schaakbord
            it.Text = ""
            it.Image = Nothing
        Next
        Dim oplossing As Stack(Of Point) = model.Oplossing
        While oplossing.Count <> 0
            Dim punt As Point = oplossing.Pop
            schaakbord(punt.X, punt.Y).Image = My.Resources.queen
        End While
        For Each it As MyLabel In schaakbord
            RemoveHandler it.Click, AddressOf Label_Click
        Next
        If handlercount <> 0 Then
            handlercount = handlercount - 1
        End If
        bttnUndo.Enabled = False
        bttnReset.Enabled = True
    End Sub

    Private Sub _8QueensForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
