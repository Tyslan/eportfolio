﻿Public Class MyLabel
    Inherits Label
    Private _x As Integer
    Private _y As Integer
    Public Sub New(ByVal x As Integer, ByVal y As Integer)
        MyBase.New()
        AutoSize = False
        Margin = New Padding(0, 0, 0, 0)
        _x = x
        _y = y
    End Sub
    Public ReadOnly Property X As Integer
        Get
            Return _x
        End Get
    End Property
    Public ReadOnly Property Y As Integer
        Get
            Return _y
        End Get
    End Property
    Protected Overrides Sub OnFontChanged(ByVal e As System.EventArgs)
    End Sub
    Protected Overrides Sub OnResize(ByVal e As System.EventArgs)
        Me.Font = New Font("Arial", Me.Height \ 3, FontStyle.Bold)
    End Sub
End Class
