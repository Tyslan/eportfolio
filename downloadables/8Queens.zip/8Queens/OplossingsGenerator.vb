﻿Public Class OplossingsGenerator
    Private _model As _8QueensModel
    Private startpos As New Point
    Private Shared random_generator As New Random
    Private _oplossing As New Stack(Of Point)
    Public Sub New(ByVal model As _8QueensModel)
        _model = model
        startpos = New Point(random_generator.Next(0, 8), random_generator.Next(0, 8))
        maak_oplossing(startpos.X)
    End Sub
    Public Function maak_oplossing(ByVal startrij As Integer) As Boolean
        If _model.GeplaatsteKoninginnen <> 8 Then
            For i As Integer = 0 To 7
                If Not _model.Vakje_Bedreigd(startrij, i Mod 8) Then
                    _model.plaatsKoningin(startrij, i)
                    _oplossing.Push(New Point(startrij, i))
                    If Not maak_oplossing((startrij + 1) Mod 8) Then
                        _model.verwijderLaatsteKoningin()
                        _oplossing.Pop()
                    Else
                        Return True
                    End If
                End If
            Next
            Return False
        Else
            Return True
        End If
    End Function
    Public ReadOnly Property Oplossing As Stack(Of Point)
        Get
            Return _oplossing
        End Get
    End Property
End Class
